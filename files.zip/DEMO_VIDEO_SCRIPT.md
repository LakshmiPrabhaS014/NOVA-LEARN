# NOVA Learn: 90-second demo video script

Target length: about 90 seconds. Record at 1920x1080 with the app running. Narration can be
recorded separately and laid over the screen capture.

| Time | Screen | Narration |
|---|---|---|
| 0:00–0:08 | NOVA Learn title card (deck slide 1) | "Most learning platforms store courses. NOVA Learn teaches." |
| 0:08–0:20 | Student home (Aanya): streak, progress ring, study chart | "Every learner gets a personal dashboard that shows what matters today." |
| 0:20–0:35 | Learning Twin orb rotating, topic dots pulsing | "The AI Learning Twin models how you learn: mastery, retention, focus, and pace." |
| 0:35–0:55 | Open AI Teacher. Teacher's note appears. Click through two lessons, mark done | "Our AI Teacher plans a practical class from your course and your weakest topic." |
| 0:55–1:10 | Checkpoint question. Pick an answer, show green/red feedback | "Checkpoints target the topic you find hardest. Every answer updates your Twin immediately." |
| 1:10–1:20 | Learning Twin page: mastery bar chart changes | "Next time, the class adapts to what you just learned." |
| 1:20–1:30 | Switch to Rohan (instructor) then Priya (admin) | "Instructors publish courses and see learner analytics. Admins manage roles and platform totals." |

## Shot checklist
- Use the seeded data so the numbers match the README.
- Before recording, run the teacher flow once so the checkpoint topic is the same each take.
- Keep the cursor visible and slow down on the checkpoint feedback.
- Add captions for accessibility.
