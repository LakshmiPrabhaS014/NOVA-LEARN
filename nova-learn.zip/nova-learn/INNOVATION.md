# What makes NOVA Learn different

Most learning management systems (Moodle, Canvas, Blackboard) are course containers: they store
content, track completion, and show grade reports. NOVA Learn adds an adaptive teaching layer on top.

| Area | Typical LMS | NOVA Learn |
|---|---|---|
| Learning path | Same course order for everyone | Learning Twin reorders focus toward weak topics |
| Teaching | Content is delivered; the learner works it out | AI Teacher runs a practical class step by step |
| Checkpoints | Quizzes at the end of a module | Checkpoints target the topic the Twin flags, mid-class |
| Feedback | Scores and reports, often days later | Immediate result, and the Twin updates before the next step |
| Motivation | Completion percentages | Streaks, badges with clear rules, visible study time |
| Teacher tools | Gradebook and content upload | Course builder, learner analytics, and class planning |
| Learner model | Static profile | Living model: mastery, retention, focus, and pace |

## The AI Teacher
- Reads the learner's enrolled course and lesson order.
- Reads the Twin's mastery map and picks the weakest topic.
- Builds a class: warm-up recall, one step per lesson, and a targeted checkpoint.
- Explains why the plan looks the way it does (the teacher's note).
- Records every checkpoint answer back into the Twin, so the next class adapts.

## Roadmap ideas
- Connect the AI Teacher to a language model for free-form explanations.
- Peer study groups matched by complementary Twin profiles.
- Instructor-side AI assistant that drafts quizzes from lesson text.
