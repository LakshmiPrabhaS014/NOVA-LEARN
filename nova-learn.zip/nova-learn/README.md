# NOVA Learn

AI-powered, colourful learning management system with student, instructor and admin dashboards,
an AI Learning Twin, and an AI Teacher that runs practical classes.

## Stack
- Frontend: React, TypeScript, Tailwind CSS, Vite, Recharts, React Router
- Backend: Node.js, Express, TypeScript
- Database: PostgreSQL

## Setup

1. Create the database and load the schema and sample data:
   ```bash
   createdb nova_learn
   export DATABASE_URL=postgres://postgres:postgres@localhost:5432/nova_learn
   psql $DATABASE_URL -f server/db/schema.sql
   psql $DATABASE_URL -f server/db/seed.sql
   ```
2. Start the API (port 4000):
   ```bash
   cd server && npm install && npm run dev
   ```
3. Start the web app (port 5173, proxies /api to the API):
   ```bash
   cd client && npm install && npm run dev
   ```
4. Open http://localhost:5173 and use the "Viewing as" menu to switch between
   Aanya (student), Rohan (instructor), and Priya (admin).

## Sample accounts
| Name | Role | Notes |
|---|---|---|
| Aanya Sharma | student | Has a Learning Twin and enrolments |
| Rohan Mehta | instructor | Owns three published courses |
| Priya Nair | admin | Platform overview and role management |

## Demo flow for the AI Teacher
1. Sign in as Aanya and open **AI Teacher**.
2. The teacher reads her Learning Twin, finds her weakest topic, and builds a class plan.
3. Complete steps, then answer the checkpoint. The answer updates her Twin in real time.
4. Open **Learning Twin** to see the orb, profile, and next steps change.

## Security note
This is a demo. "Viewing as" stands in for real sign-in. Add authentication (for example, sessions or
JWT with role checks on every route) before any real use.
