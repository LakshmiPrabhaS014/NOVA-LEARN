import { createContext, useContext, useEffect, useState } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { api, type User } from "./lib/api";
import Shell from "./components/Shell";
import StudentHome from "./pages/StudentHome";
import Courses from "./pages/Courses";
import CourseDetailPage from "./pages/CourseDetail";
import TwinPage from "./pages/Twin";
import AITeacher from "./pages/AITeacher";
import Instructor from "./pages/Instructor";
import Admin from "./pages/Admin";

type Session = { users: User[]; user: User | null; setUserId: (id: number) => void };

const SessionContext = createContext<Session>({ users: [], user: null, setUserId: () => {} });
export const useSession = () => useContext(SessionContext);

const homeFor = (role?: User["role"]) =>
  role === "instructor" ? "/instructor" : role === "admin" ? "/admin" : "/student";

export default function App() {
  const [users, setUsers] = useState<User[]>([]);
  const [userId, setUserId] = useState(1);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<User[]>("/users").then(setUsers).catch((e: Error) => setError(e.message));
  }, []);

  const user = users.find((u) => u.id === userId) ?? null;

  if (error) {
    return (
      <div className="mx-auto max-w-xl p-10">
        <div className="rounded-[28px] bg-white p-8 shadow-card" role="alert">
          <h1 className="font-display text-3xl font-extrabold">We can't reach the API</h1>
          <p className="mt-3">{error}. Start the server with <code className="font-semibold">npm run dev</code> inside <code>server/</code>, then refresh.</p>
        </div>
      </div>
    );
  }
  if (!users.length) {
    return <p className="p-10 font-display text-2xl font-bold">Loading NOVA Learn…</p>;
  }

  return (
    <SessionContext.Provider value={{ users, user, setUserId }}>
      <Shell>
        <Routes>
          <Route path="/" element={<Navigate to={homeFor(user?.role)} replace />} />
          <Route path="/student" element={<StudentHome />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/courses/:id" element={<CourseDetailPage />} />
          <Route path="/twin" element={<TwinPage />} />
          <Route path="/teacher" element={<AITeacher />} />
          <Route path="/instructor" element={<Instructor />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="*" element={<p className="font-semibold">That page doesn't exist. <a className="text-violet underline" href="/">Go home</a>.</p>} />
        </Routes>
      </Shell>
    </SessionContext.Provider>
  );
}
