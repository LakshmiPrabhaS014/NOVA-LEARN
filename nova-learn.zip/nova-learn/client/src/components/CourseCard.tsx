import { Link } from "react-router-dom";
import type { Course } from "../lib/api";
import { Bar, Pill } from "./ui";

export function CourseCard({ course, onEnroll }: { course: Course; onEnroll?: (id: number) => void }) {
  return (
    <article className="overflow-hidden rounded-[28px] bg-white shadow-card transition hover:-translate-y-1">
      <div className="relative flex h-28 items-center p-5"
        style={{ background: `linear-gradient(135deg, ${course.color}, #FFC93C)` }}>
        <span className="text-5xl" aria-hidden="true">{course.emoji}</span>
        <div className="absolute right-4 top-4"><Pill tint="#FFFFFFdd">{course.level}</Pill></div>
      </div>
      <div className="space-y-3 p-5">
        <p className="text-xs font-bold uppercase tracking-wide text-ink/75">
          {course.category} · {course.instructor}
        </p>
        <h3 className="font-display text-lg font-extrabold leading-snug">{course.title}</h3>
        {course.enrolled ? (
          <Bar value={course.progress} color={course.color} label="Your progress" />
        ) : onEnroll ? (
          <button onClick={() => onEnroll(course.id)}
            className="rounded-full bg-sun px-4 py-2 text-sm font-bold text-ink hover:brightness-95">
            Enrol now
          </button>
        ) : null}
        <Link to={`/courses/${course.id}`} className="inline-block font-bold text-violet underline-offset-4 hover:underline">
          Open course →
        </Link>
      </div>
    </article>
  );
}
