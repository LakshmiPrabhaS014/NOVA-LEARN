import { NavLink } from "react-router-dom";
import type { ReactNode } from "react";
import { useSession } from "../App";
import { Logo } from "./ui";
import type { Role } from "../lib/api";

const NAV: Record<Role, [string, string, string][]> = {
  student: [
    ["/student", "Home", "🏠"],
    ["/courses", "Courses", "📚"],
    ["/teacher", "AI Teacher", "🤖"],
    ["/twin", "Learning Twin", "🧠"],
  ],
  instructor: [
    ["/instructor", "Teaching", "🎯"],
    ["/courses", "Catalogue", "📚"],
  ],
  admin: [
    ["/admin", "Overview", "🛰️"],
    ["/courses", "All courses", "📚"],
  ],
};

const linkClass = ({ isActive }: { isActive: boolean }) =>
  `flex items-center gap-3 whitespace-nowrap rounded-2xl px-4 py-3 font-semibold transition focus:outline-none focus-visible:ring-4 focus-visible:ring-violet/40 ${
    isActive ? "bg-white shadow-card" : "hover:bg-white/70"
  }`;

export default function Shell({ children }: { children: ReactNode }) {
  const { user, users, setUserId } = useSession();
  const items = user ? NAV[user.role] : [];

  return (
    <div className="min-h-screen md:flex">
      <aside className="sticky top-0 hidden h-screen w-64 flex-col gap-8 p-6 md:flex">
        <Logo />
        <nav className="flex flex-col gap-2" aria-label="Main">
          {items.map(([to, label, icon]) => (
            <NavLink key={to} to={to} className={linkClass}>
              <span aria-hidden="true">{icon}</span>
              {label}
            </NavLink>
          ))}
        </nav>
      </aside>

      <div className="min-w-0 flex-1">
        <header className="flex flex-wrap items-center gap-4 px-5 pt-6 md:px-10">
          <div className="md:hidden"><Logo /></div>
          <div className="ml-auto flex items-center gap-3">
            <label htmlFor="persona" className="text-sm font-semibold">Viewing as</label>
            <select
              id="persona"
              value={user?.id ?? ""}
              onChange={(e) => setUserId(Number(e.target.value))}
              className="rounded-full bg-white px-4 py-2 font-semibold shadow-card focus:outline-none focus-visible:ring-4 focus-visible:ring-violet/40"
            >
              {users.map((u) => (
                <option key={u.id} value={u.id}>{u.name} · {u.role}</option>
              ))}
            </select>
            {user && (
              <span className="grid h-11 w-11 place-items-center rounded-full font-display font-extrabold"
                style={{ background: user.avatar_color }} aria-hidden="true">{user.name[0]}</span>
            )}
          </div>
        </header>

        <nav className="flex gap-2 overflow-x-auto px-5 pt-4 md:hidden" aria-label="Main mobile">
          {items.map(([to, label]) => (
            <NavLink key={to} to={to} className={linkClass}>{label}</NavLink>
          ))}
        </nav>

        <main id="main" className="mx-auto max-w-7xl px-5 py-8 md:px-10">{children}</main>
      </div>
    </div>
  );
}
