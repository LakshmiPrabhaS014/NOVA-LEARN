import { useEffect, useState, type ButtonHTMLAttributes, type ReactNode } from "react";

export function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-[#FF6B5A] via-[#FF5FA2] to-[#6D4AFF] shadow-pop">
        <svg viewBox="0 0 24 24" className="h-6 w-6" aria-hidden="true">
          <path d="M12 2l2.4 6.6L21 11l-6.6 2.4L12 20l-2.4-6.6L3 11l6.6-2.4z" fill="#FFC93C" />
        </svg>
      </div>
      <div className="leading-tight">
        <p className="font-display text-xl font-extrabold">NOVA Learn</p>
        <p className="text-xs font-semibold text-ink/70">Learning that adapts to you</p>
      </div>
    </div>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-[28px] bg-white p-6 shadow-card ${className}`}>{children}</section>;
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-4 flex items-center justify-between gap-4">
      <h2 className="font-display text-2xl font-extrabold">{children}</h2>
      {action}
    </div>
  );
}

export function ProgressRing({ value, color, size = 96, label }: { value: number; color: string; size?: number; label?: string }) {
  const r = 40;
  const c = 2 * Math.PI * r;
  const [shown, setShown] = useState(0);
  useEffect(() => {
    const t = requestAnimationFrame(() => setShown(value));
    return () => cancelAnimationFrame(t);
  }, [value]);
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}
      role="img" aria-label={`${label ?? "Progress"}: ${value}%`}>
      <svg viewBox="0 0 100 100" className="-rotate-90 h-full w-full" aria-hidden="true">
        <circle cx="50" cy="50" r={r} fill="none" stroke="#EFE7FF" strokeWidth="12" />
        <circle cx="50" cy="50" r={r} fill="none" stroke={color} strokeWidth="12" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c - (shown / 100) * c}
          style={{ transition: "stroke-dashoffset 1.1s cubic-bezier(.2,.8,.2,1)" }} />
      </svg>
      <span className="absolute font-display text-lg font-extrabold">{value}%</span>
    </div>
  );
}

export function Bar({ value, color, label }: { value: number; color: string; label: string }) {
  const [shown, setShown] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setShown(value), 60);
    return () => clearTimeout(t);
  }, [value]);
  return (
    <div>
      <div className="mb-1 flex justify-between text-sm font-semibold">
        <span>{label}</span><span>{value}%</span>
      </div>
      <div className="h-3 w-full overflow-hidden rounded-full bg-ink/10" role="progressbar"
        aria-label={label} aria-valuenow={value} aria-valuemin={0} aria-valuemax={100}>
        <div className="h-full rounded-full transition-[width] duration-1000 ease-out"
          style={{ width: `${shown}%`, background: color }} />
      </div>
    </div>
  );
}

export function Button({
  variant = "primary",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "sun" }) {
  const styles = {
    primary: "bg-violet text-white hover:bg-[#5a36f0]",
    ghost: "bg-white text-ink shadow-card hover:bg-[#f6f0ff]",
    sun: "bg-sun text-ink hover:brightness-95",
  };
  return (
    <button
      {...props}
      className={`rounded-full px-5 py-2.5 font-bold transition hover:-translate-y-0.5 focus:outline-none focus-visible:ring-4 focus-visible:ring-violet/40 disabled:cursor-not-allowed disabled:opacity-50 ${styles[variant]} ${className}`}
    />
  );
}

export function Pill({ children, tint }: { children: ReactNode; tint: string }) {
  return <span className="rounded-full px-3 py-1 text-xs font-bold text-ink" style={{ background: tint }}>{children}</span>;
}

export function TwinOrb({ mastery }: { mastery: Record<string, number> }) {
  const entries = Object.entries(mastery);
  const avg = entries.length ? Math.round(entries.reduce((s, [, v]) => s + v, 0) / entries.length) : 0;
  const palette = ["#FF6B5A", "#FFC93C", "#14B8A6", "#FF5FA2", "#A3E635", "#8FB3FF"];
  const orbit = 112;
  return (
    <svg viewBox="0 0 300 300" className="mx-auto h-72 w-72" role="img"
      aria-label={`AI Learning Twin. Average mastery ${avg}% across ${entries.length} topics.`}>
      <defs>
        <radialGradient id="twin-orb" cx="35%" cy="30%" r="75%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="30%" stopColor="#C9B8FF" />
          <stop offset="70%" stopColor="#6D4AFF" />
          <stop offset="100%" stopColor="#C93A7A" />
        </radialGradient>
      </defs>
      <circle cx="150" cy="150" r={orbit} fill="none" stroke="#6D4AFF" strokeOpacity=".25" strokeDasharray="4 8" strokeWidth="2" />
      <g className="animate-breathe">
        <circle cx="150" cy="150" r="66" fill="url(#twin-orb)" />
        <text x="150" y="160" textAnchor="middle" fontSize="30" fontWeight="800" fill="#FFFFFF" fontFamily="Bricolage Grotesque, sans-serif">{avg}%</text>
      </g>
      {entries.map(([topic, v], i) => {
        const a = (i / entries.length) * Math.PI * 2 - Math.PI / 2;
        const x = 150 + Math.cos(a) * orbit;
        const y = 150 + Math.sin(a) * orbit;
        const color = palette[i % palette.length];
        return (
          <g key={topic} className="animate-float" style={{ animationDelay: `${i * 0.5}s` }}>
            <circle cx={x} cy={y} r={12 + v / 9} fill={color} stroke="#FFFFFF" strokeWidth="3" />
            <text x={x} y={y + 4} textAnchor="middle" fontSize="11" fontWeight="700" fill="#2B1F4A">{v}</text>
            <text x={x} y={y + (y < 150 ? -(20 + v / 9) : 30 + v / 9)} textAnchor="middle" fontSize="12" fontWeight="700" fill="#2B1F4A">{topic}</text>
          </g>
        );
      })}
    </svg>
  );
}
