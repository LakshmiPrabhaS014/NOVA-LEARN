export const api = async <T,>(path: string, init?: RequestInit): Promise<T> => {
  const res = await fetch(`/api${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error ?? `Request failed with status ${res.status}.`);
  return data as T;
};

export const post = <T,>(path: string, body: unknown) =>
  api<T>(path, { method: "POST", body: JSON.stringify(body) });

export const patch = <T,>(path: string, body: unknown) =>
  api<T>(path, { method: "PATCH", body: JSON.stringify(body) });

export type Role = "student" | "instructor" | "admin";

export type User = {
  id: number;
  name: string;
  email: string;
  role: Role;
  avatar_color: string;
};

export type Course = {
  id: number;
  title: string;
  description: string;
  category: string;
  level: string;
  color: string;
  emoji: string;
  status: "draft" | "published" | "archived";
  instructor: string;
  progress: number;
  enrolled: boolean;
  learners: number;
};

export type Lesson = { id: number; title: string; duration_min: number; position: number; completed: boolean };

export type CourseDetail = Course & { lessons: Lesson[]; quizzes: { id: number; title: string }[] };

export type Question = { id: number; prompt: string; options: string[]; topic: string };

export type Quiz = { id: number; title: string; course_id: number; questions: Question[] };

export type AttemptResult = {
  attemptId: number;
  score: number;
  total: number;
  topics: Record<string, { correct: number; total: number }>;
};

export type Twin = {
  user_id: number;
  pace: number;
  retention: number;
  focus: number;
  mastery: Record<string, number>;
  streak: number;
  weeklyMinutes: { day: string; minutes: number }[];
  recommendations: { topic: string; score: number; action: string }[];
  updated_at: string;
};

export type InstructorCourse = {
  id: number;
  title: string;
  status: Course["status"];
  color: string;
  emoji: string;
  learners: number;
  avg_progress: number;
  avg_quiz: number | null;
};

export type AdminOverview = {
  totals: { students: number; instructors: number; courses: number; enrollments: number; avg_progress: number };
  monthly: { month: string; enrollments: number }[];
  users: (User & { enrollments: number })[];
};
