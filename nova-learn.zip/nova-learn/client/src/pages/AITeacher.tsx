import { useEffect, useState } from "react";
import { api, post, type Course } from "../lib/api";
import { useSession } from "../App";
import { Button, Card, Pill, SectionTitle } from "../components/ui";

type Step =
  | { type: "warm-up"; title: string; minutes: number; text: string }
  | { type: "lesson"; lessonId: number; title: string; minutes: number; text: string }
  | { type: "checkpoint"; title: string; minutes: number; questionId: number; prompt: string; options: string[]; text: string };

type ClassPlan = { courseTitle: string; teacherNote: string; steps: Step[] };

const TYPE_TINT: Record<Step["type"], string> = {
  "warm-up": "#FFC93C",
  lesson: "#A3E635",
  checkpoint: "#FF9CC2",
};

export default function AITeacher() {
  const { user } = useSession();
  const [courses, setCourses] = useState<Course[]>([]);
  const [courseId, setCourseId] = useState<number | null>(null);
  const [plan, setPlan] = useState<ClassPlan | null>(null);
  const [done, setDone] = useState<Set<number>>(new Set());
  const [checkResult, setCheckResult] = useState<{ correct: boolean; correctIndex: number } | null>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    api<Course[]>(`/courses?userId=${user.id}`)
      .then((all) => {
        const mine = all.filter((c) => c.enrolled && c.status === "published");
        setCourses(mine);
        setCourseId(mine[0]?.id ?? null);
      })
      .catch((e: Error) => setError(e.message));
  }, [user?.id]);

  useEffect(() => {
    if (!user || !courseId) return;
    setDone(new Set());
    setCheckResult(null);
    setPicked(null);
    api<ClassPlan>(`/teacher/class/${courseId}?userId=${user.id}`)
      .then(setPlan)
      .catch((e: Error) => setError(e.message));
  }, [courseId, user?.id]);

  const toggle = (i: number) =>
    setDone((prev) => {
      const next = new Set(prev);
      next.has(i) ? next.delete(i) : next.add(i);
      return next;
    });

  const answer = async (step: Extract<Step, { type: "checkpoint" }>, idx: number) => {
    setPicked(idx);
    const res = await post<{ correct: boolean; correctIndex: number }>("/teacher/checkpoint", {
      questionId: step.questionId, answerIndex: idx, userId: user?.id,
    });
    setCheckResult(res);
  };

  if (error) return <Card><p role="alert" className="font-semibold">{error}</p></Card>;

  if (!courses.length) {
    return <Card><p className="font-semibold">Enrol in a published course first, then your AI Teacher can plan a class for you.</p></Card>;
  }

  const totalMinutes = plan?.steps.reduce((s, st) => s + st.minutes, 0) ?? 0;
  const progress = plan ? Math.round((done.size / plan.steps.length) * 100) : 0;

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl font-extrabold">AI Teacher: live practical class</h1>
          <p className="mt-2 max-w-2xl font-semibold">
            Your teacher plans a practical session from your course and your Learning Twin, then guides you
            step by step with checkpoints that adapt to your weakest topic.
          </p>
        </div>
        <div>
          <label htmlFor="course-pick" className="mb-1 block text-sm font-bold">Choose a course</label>
          <select id="course-pick" value={courseId ?? ""} onChange={(e) => setCourseId(Number(e.target.value))}
            className="rounded-full bg-white px-4 py-2 font-semibold shadow-card focus:outline-none focus-visible:ring-4 focus-visible:ring-violet/40">
            {courses.map((c) => <option key={c.id} value={c.id}>{c.emoji} {c.title}</option>)}
          </select>
        </div>
      </div>

      {plan && (
        <>
          <div className="grid gap-6 lg:grid-cols-[1fr_1.6fr]">
            <Card className="bg-gradient-to-br from-violet to-pink text-white">
              <p className="text-sm font-bold uppercase tracking-wide">Teacher's note</p>
              <p className="mt-3 font-display text-xl font-bold leading-snug">{plan.teacherNote}</p>
              <div className="mt-6 flex flex-wrap gap-2">
                <Pill tint="#FFFFFFee">{plan.steps.length} steps</Pill>
                <Pill tint="#FFFFFFee">≈ {totalMinutes} min</Pill>
              </div>
              <div className="mt-6" role="progressbar" aria-label="Class progress" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
                <div className="mb-1 text-sm font-bold">{progress}% complete</div>
                <div className="h-3 overflow-hidden rounded-full bg-white/30">
                  <div className="h-full rounded-full bg-sun transition-[width] duration-700" style={{ width: `${progress}%` }} />
                </div>
              </div>
            </Card>

            <Card>
              <SectionTitle>Today's class</SectionTitle>
              <ol className="space-y-3">
                {plan.steps.map((step, i) => {
                  const isDone = done.has(i);
                  return (
                    <li key={i} className={`rounded-2xl p-4 transition ${isDone ? "bg-[#f1ffd6]" : "bg-[#faf7ff]"}`}>
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <span className="grid h-9 w-9 place-items-center rounded-full font-bold" style={{ background: TYPE_TINT[step.type] }} aria-hidden="true">{i + 1}</span>
                          <div>
                            <p className="font-bold">{step.title}</p>
                            <p className="text-xs font-semibold uppercase text-ink/75">{step.type} · {step.minutes} min</p>
                          </div>
                        </div>
                        <Button variant={isDone ? "ghost" : "primary"} onClick={() => toggle(i)} aria-pressed={isDone}>
                          {isDone ? "Done ✓" : "Mark done"}
                        </Button>
                      </div>
                      <p className="mt-3 text-sm">{step.text}</p>

                      {step.type === "checkpoint" && (
                        <fieldset className="mt-4 space-y-2">
                          <legend className="font-bold">{step.prompt}</legend>
                          {step.options.map((opt, idx) => (
                            <button key={idx} onClick={() => answer(step, idx)} disabled={checkResult !== null}
                              className={`block w-full rounded-2xl bg-white px-4 py-3 text-left font-semibold shadow-card transition disabled:cursor-default ${
                                checkResult && idx === checkResult.correctIndex ? "ring-4 ring-lime" :
                                checkResult && picked === idx && !checkResult.correct ? "ring-4 ring-coral" : ""}`}>
                              {opt}
                            </button>
                          ))}
                          {checkResult && (
                            <p role="status" className="font-bold">
                              {checkResult.correct ? "Nailed it. Your Learning Twin has recorded this." : "Not quite. The highlighted green answer is correct, and this topic will come back soon."}
                            </p>
                          )}
                        </fieldset>
                      )}
                    </li>
                  );
                })}
              </ol>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
