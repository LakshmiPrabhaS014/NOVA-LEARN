import { useEffect, useState } from "react";
import { Bar as ChartBar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api, patch, type AdminOverview, type Role } from "../lib/api";
import { Card, SectionTitle } from "../components/ui";

export default function Admin() {
  const [data, setData] = useState<AdminOverview | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const load = () => api<AdminOverview>("/admin/overview").then(setData).catch((e: Error) => setMessage(e.message));
  useEffect(() => { load(); }, []);

  const changeRole = async (id: number, role: Role) => {
    try {
      await patch(`/users/${id}`, { role });
      setMessage("Role updated.");
      load();
    } catch (e) {
      setMessage((e as Error).message);
    }
  };

  if (!data) return <p className="font-semibold">{message ?? "Loading platform overview…"}</p>;

  const stats = [
    ["Students", data.totals.students],
    ["Instructors", data.totals.instructors],
    ["Courses", data.totals.courses],
    ["Enrolments", data.totals.enrollments],
    ["Avg progress", `${data.totals.avg_progress}%`],
  ] as const;

  return (
    <div className="space-y-8">
      <h1 className="font-display text-4xl font-extrabold">Platform overview</h1>
      {message && <p role="status" className="rounded-2xl bg-white p-4 font-semibold shadow-card">{message}</p>}

      <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
        {stats.map(([label, value], i) => (
          <Card key={label} className={["bg-[#FFE9A8]", "bg-[#C8F2EC]", "bg-[#FFD3E6]", "bg-[#DCCFFF]", "bg-[#E4FAB0]"][i]}>
            <p className="text-sm font-bold">{label}</p>
            <p className="mt-1 font-display text-3xl font-extrabold">{value}</p>
          </Card>
        ))}
      </div>

      <Card>
        <SectionTitle>Enrolments by month</SectionTitle>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.monthly}>
              <CartesianGrid stroke="#EFE7FF" vertical={false} />
              <XAxis dataKey="month" stroke="#2B1F4A" tickLine={false} />
              <YAxis stroke="#2B1F4A" tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip />
              <ChartBar dataKey="enrollments" fill="#FF5FA2" radius={[10, 10, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card>
        <SectionTitle>Users and roles</SectionTitle>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-left">
            <thead>
              <tr className="border-b border-ink/15 text-sm">
                <th scope="col" className="py-3">Name</th>
                <th scope="col" className="py-3">Email</th>
                <th scope="col" className="py-3">Enrolments</th>
                <th scope="col" className="py-3">Role</th>
              </tr>
            </thead>
            <tbody>
              {data.users.map((u) => (
                <tr key={u.id} className="border-b border-ink/10">
                  <td className="py-3 font-bold">{u.name}</td>
                  <td className="py-3">{u.email}</td>
                  <td className="py-3">{u.enrollments}</td>
                  <td className="py-3">
                    <label className="sr-only" htmlFor={`role-${u.id}`}>Role for {u.name}</label>
                    <select id={`role-${u.id}`} value={u.role} onChange={(e) => changeRole(u.id, e.target.value as Role)}
                      className="rounded-full bg-white px-3 py-1.5 font-semibold shadow-card">
                      <option value="student">student</option>
                      <option value="instructor">instructor</option>
                      <option value="admin">admin</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
