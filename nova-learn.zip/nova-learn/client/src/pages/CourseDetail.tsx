import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { api, post, type AttemptResult, type CourseDetail, type Quiz } from "../lib/api";
import { useSession } from "../App";
import { Card, Pill, ProgressRing, Button, SectionTitle } from "../components/ui";

export default function CourseDetailPage() {
  const { id } = useParams();
  const { user } = useSession();
  const [course, setCourse] = useState<CourseDetail | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const load = () => {
    if (!user || !id) return;
    api<CourseDetail>(`/courses/${id}?userId=${user.id}`).then(setCourse).catch((e: Error) => setMessage(e.message));
  };
  useEffect(load, [id, user?.id]);

  if (!course) return <p className="font-semibold">{message ?? "Loading course…"}</p>;

  const completeLesson = async (lessonId: number) => {
    await post(`/lessons/${lessonId}/complete`, { userId: user?.id });
    load();
  };

  const enrol = async () => {
    await post(`/courses/${course.id}/enroll`, { userId: user?.id });
    load();
  };

  const done = course.lessons.filter((l) => l.completed).length;

  return (
    <div className="space-y-8">
      <Link to="/courses" className="font-bold text-violet underline">← Back to courses</Link>

      <header className="flex flex-wrap items-center gap-6 rounded-[32px] p-8 shadow-card"
        style={{ background: `linear-gradient(135deg, ${course.color}, #FFC93C)` }}>
        <span className="text-6xl" aria-hidden="true">{course.emoji}</span>
        <div className="min-w-64 flex-1">
          <div className="flex flex-wrap gap-2">
            <Pill tint="#FFFFFFdd">{course.category}</Pill>
            <Pill tint="#FFFFFFdd">{course.level}</Pill>
            {course.status !== "published" && <Pill tint="#FFFFFFdd">{course.status}</Pill>}
          </div>
          <h1 className="mt-3 font-display text-4xl font-extrabold">{course.title}</h1>
          <p className="mt-2 font-semibold">{course.description}</p>
          <p className="mt-1 text-sm font-semibold">Taught by {course.instructor}</p>
        </div>
        {course.enrolled
          ? <ProgressRing value={course.progress} color="#6D4AFF" label="Course progress" />
          : <Button onClick={enrol}>Enrol in this course</Button>}
      </header>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <Card>
          <SectionTitle>Lessons · {done}/{course.lessons.length} done</SectionTitle>
          <ol className="space-y-3">
            {course.lessons.map((l) => (
              <li key={l.id} className="flex items-center gap-4 rounded-2xl bg-[#faf7ff] p-4">
                <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-full font-bold ${l.completed ? "bg-lime" : "bg-white shadow-card"}`}
                  aria-hidden="true">{l.completed ? "✓" : l.position}</span>
                <div className="flex-1">
                  <p className="font-bold">{l.title}</p>
                  <p className="text-sm text-ink/75">{l.duration_min} min</p>
                </div>
                {course.enrolled && !l.completed && (
                  <Button variant="ghost" onClick={() => completeLesson(l.id)}>Mark complete</Button>
                )}
              </li>
            ))}
          </ol>
        </Card>

        <div className="space-y-6">
          {course.quizzes.map((q) => <QuizPlayer key={q.id} quizId={q.id} title={q.title} />)}
          {!course.quizzes.length && <Card><p className="font-semibold">No quiz for this course yet.</p></Card>}
        </div>
      </div>
    </div>
  );
}

function QuizPlayer({ quizId, title }: { quizId: number; title: string }) {
  const { user } = useSession();
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [result, setResult] = useState<AttemptResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<Quiz>(`/quizzes/${quizId}`).then(setQuiz).catch((e: Error) => setError(e.message));
  }, [quizId]);

  if (error) return <Card><p role="alert" className="font-semibold">{error}</p></Card>;
  if (!quiz) return <Card><p>Loading quiz…</p></Card>;

  const allAnswered = quiz.questions.every((q) => answers[String(q.id)] !== undefined);

  const submit = async () => {
    const res = await post<AttemptResult>(`/quizzes/${quizId}/attempt`, { userId: user?.id, answers });
    setResult(res);
  };

  return (
    <Card>
      <SectionTitle>{title}</SectionTitle>
      {!result ? (
        <form onSubmit={(e) => { e.preventDefault(); if (allAnswered) submit(); }} className="space-y-5">
          {quiz.questions.map((q, i) => (
            <fieldset key={q.id} className="space-y-2">
              <legend className="font-bold">{i + 1}. {q.prompt}</legend>
              {q.options.map((opt, idx) => (
                <label key={idx} className="flex cursor-pointer items-center gap-3 rounded-2xl bg-[#faf7ff] px-4 py-3 has-[:checked]:bg-[#e9e1ff] has-[:checked]:font-bold">
                  <input type="radio" name={`q${q.id}`} className="h-4 w-4 accent-violet"
                    checked={answers[String(q.id)] === idx}
                    onChange={() => setAnswers({ ...answers, [String(q.id)]: idx })} />
                  {opt}
                </label>
              ))}
            </fieldset>
          ))}
          <Button type="submit" disabled={!allAnswered}>Check my answers</Button>
          {!allAnswered && <p className="text-sm text-ink/75">Answer every question to submit.</p>}
        </form>
      ) : (
        <div className="space-y-4" role="status">
          <p className="font-display text-3xl font-extrabold">{result.score} / {result.total} correct</p>
          <ul className="space-y-2">
            {Object.entries(result.topics).map(([topic, r]) => (
              <li key={topic} className="flex justify-between rounded-2xl bg-[#faf7ff] px-4 py-2">
                <span className="font-semibold">{topic}</span><span>{r.correct}/{r.total}</span>
              </li>
            ))}
          </ul>
          <p className="text-sm">Your Learning Twin has updated with these results.</p>
        </div>
      )}
    </Card>
  );
}
