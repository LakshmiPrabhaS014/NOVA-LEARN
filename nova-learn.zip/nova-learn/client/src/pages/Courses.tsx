import { useEffect, useMemo, useState } from "react";
import { api, post, type Course } from "../lib/api";
import { useSession } from "../App";
import { CourseCard } from "../components/CourseCard";
import { SectionTitle } from "../components/ui";

export default function Courses() {
  const { user } = useSession();
  const [courses, setCourses] = useState<Course[]>([]);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [message, setMessage] = useState<string | null>(null);

  const load = () => {
    if (!user) return;
    api<Course[]>(`/courses?userId=${user.id}`).then(setCourses).catch((e: Error) => setMessage(e.message));
  };
  useEffect(load, [user?.id]);

  const visible = useMemo(() => {
    return courses
      .filter((c) => user?.role === "student" ? c.status === "published" : true)
      .filter((c) => category === "All" || c.category === category)
      .filter((c) => c.title.toLowerCase().includes(query.toLowerCase()));
  }, [courses, query, category, user?.role]);

  const categories = ["All", ...new Set(courses.map((c) => c.category))];

  const enrol = async (courseId: number) => {
    if (!user) return;
    try {
      await post(`/courses/${courseId}/enroll`, { userId: user.id });
      setMessage("Enrolled. Your course is ready in Continue learning.");
      load();
    } catch (e) {
      setMessage((e as Error).message);
    }
  };

  return (
    <div className="space-y-6">
      <SectionTitle>Course catalogue</SectionTitle>
      <div className="flex flex-wrap items-center gap-3">
        <label className="sr-only" htmlFor="search">Search courses</label>
        <input id="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search courses…"
          className="min-w-64 flex-1 rounded-full bg-white px-5 py-3 shadow-card focus:outline-none focus-visible:ring-4 focus-visible:ring-violet/40" />
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by category">
          {categories.map((cat) => (
            <button key={cat} aria-pressed={category === cat} onClick={() => setCategory(cat)}
              className={`rounded-full px-4 py-2 font-bold transition focus:outline-none focus-visible:ring-4 focus-visible:ring-violet/40 ${category === cat ? "bg-violet text-white" : "bg-white shadow-card"}`}>
              {cat}
            </button>
          ))}
        </div>
      </div>
      {message && <p role="status" className="rounded-2xl bg-white p-4 font-semibold shadow-card">{message}</p>}
      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {visible.map((c) => (
          <CourseCard key={c.id} course={c} onEnroll={user?.role === "student" && !c.enrolled ? enrol : undefined} />
        ))}
      </div>
      {!visible.length && <p className="font-semibold">No courses match those filters.</p>}
    </div>
  );
}
