import { useEffect, useState, type FormEvent } from "react";
import { Bar as ChartBar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api, patch, post, type InstructorCourse } from "../lib/api";
import { useSession } from "../App";
import { Button, Card, Pill, SectionTitle } from "../components/ui";

export default function Instructor() {
  const { user } = useSession();
  const [courses, setCourses] = useState<InstructorCourse[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [form, setForm] = useState({ title: "", category: "General", level: "Beginner", description: "" });

  const load = () => {
    if (!user) return;
    api<InstructorCourse[]>(`/instructor/${user.id}/analytics`).then(setCourses).catch((e: Error) => setMessage(e.message));
  };
  useEffect(load, [user?.id]);

  const create = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    try {
      await post("/courses", { ...form, instructorId: user.id, emoji: "✨", color: "#FF5FA2" });
      setForm({ title: "", category: "General", level: "Beginner", description: "" });
      setMessage("Course created as a draft. Publish it when you're ready.");
      load();
    } catch (err) {
      setMessage((err as Error).message);
    }
  };

  const togglePublish = async (c: InstructorCourse) => {
    await patch(`/courses/${c.id}`, { status: c.status === "published" ? "draft" : "published" });
    load();
  };

  const chart = courses.map((c) => ({ name: c.title.split(" ").slice(0, 2).join(" "), progress: c.avg_progress, quiz: c.avg_quiz ?? 0 }));

  return (
    <div className="space-y-8">
      <h1 className="font-display text-4xl font-extrabold">Instructor dashboard</h1>
      {message && <p role="status" className="rounded-2xl bg-white p-4 font-semibold shadow-card">{message}</p>}

      <Card>
        <SectionTitle>Learner analytics</SectionTitle>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chart}>
              <CartesianGrid stroke="#EFE7FF" vertical={false} />
              <XAxis dataKey="name" stroke="#2B1F4A" tickLine={false} />
              <YAxis domain={[0, 100]} stroke="#2B1F4A" tickLine={false} axisLine={false} />
              <Tooltip />
              <ChartBar dataKey="progress" name="Avg progress %" fill="#6D4AFF" radius={[10, 10, 0, 0]} />
              <ChartBar dataKey="quiz" name="Avg quiz %" fill="#14B8A6" radius={[10, 10, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <Card>
          <SectionTitle>Your courses</SectionTitle>
          <ul className="space-y-3">
            {courses.map((c) => (
              <li key={c.id} className="flex flex-wrap items-center gap-4 rounded-2xl bg-[#faf7ff] p-4">
                <span className="text-3xl" aria-hidden="true">{c.emoji}</span>
                <div className="min-w-48 flex-1">
                  <p className="font-bold">{c.title}</p>
                  <p className="text-sm">{c.learners} learners · {c.avg_progress}% avg progress · {c.avg_quiz ?? "–"}% avg quiz</p>
                </div>
                <Pill tint={c.status === "published" ? "#A3E635" : "#FFC93C"}>{c.status}</Pill>
                <Button variant="ghost" onClick={() => togglePublish(c)}>
                  {c.status === "published" ? "Unpublish" : "Publish"}
                </Button>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <SectionTitle>Create a course</SectionTitle>
          <form onSubmit={create} className="space-y-4">
            <div>
              <label htmlFor="ct" className="mb-1 block font-bold">Title</label>
              <input id="ct" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="w-full rounded-2xl border border-ink/15 px-4 py-3 focus:outline-none focus-visible:ring-4 focus-visible:ring-violet/40" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="cc" className="mb-1 block font-bold">Category</label>
                <input id="cc" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full rounded-2xl border border-ink/15 px-4 py-3" />
              </div>
              <div>
                <label htmlFor="cl" className="mb-1 block font-bold">Level</label>
                <select id="cl" value={form.level} onChange={(e) => setForm({ ...form, level: e.target.value })}
                  className="w-full rounded-2xl border border-ink/15 px-4 py-3">
                  <option>Beginner</option><option>Intermediate</option><option>Advanced</option>
                </select>
              </div>
            </div>
            <div>
              <label htmlFor="cd" className="mb-1 block font-bold">Description</label>
              <textarea id="cd" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full rounded-2xl border border-ink/15 px-4 py-3" />
            </div>
            <Button type="submit">Create draft</Button>
          </form>
        </Card>
      </div>
    </div>
  );
}
