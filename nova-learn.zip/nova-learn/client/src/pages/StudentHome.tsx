import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api, type Course, type Twin } from "../lib/api";
import { useSession } from "../App";
import { Card, ProgressRing, SectionTitle, Button } from "../components/ui";
import { CourseCard } from "../components/CourseCard";

export default function StudentHome() {
  const { user } = useSession();
  const [courses, setCourses] = useState<Course[]>([]);
  const [twin, setTwin] = useState<Twin | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      api<Course[]>(`/courses?userId=${user.id}`),
      api<Twin>(`/twin/${user.id}`).catch(() => null),
    ])
      .then(([c, t]) => { setCourses(c); setTwin(t); })
      .catch((e: Error) => setError(e.message));
  }, [user?.id]);

  const enrolled = courses.filter((c) => c.enrolled && c.status === "published");
  const avg = enrolled.length ? Math.round(enrolled.reduce((s, c) => s + c.progress, 0) / enrolled.length) : 0;
  const minutes = twin?.weeklyMinutes.reduce((s, d) => s + d.minutes, 0) ?? 0;
  const first = user?.name.split(" ")[0] ?? "there";

  return (
    <div className="space-y-8">
      {error && <p role="alert" className="rounded-2xl bg-white p-4 font-semibold shadow-card">{error}</p>}

      <header className="relative overflow-hidden rounded-[32px] bg-gradient-to-r from-[#C93A2A] via-[#C92F7A] to-[#5B3BE6] p-8 text-white shadow-pop">
        <div className="absolute -right-10 -top-12 h-56 w-56 rounded-full bg-sun/50 blur-2xl" aria-hidden="true" />
        <div className="relative grid gap-6 md:grid-cols-[1fr_auto] md:items-center">
          <div>
            <p className="font-semibold">Ready to learn today?</p>
            <h1 className="mt-1 font-display text-4xl font-extrabold md:text-5xl">
              Hi {first}, you're on a {twin?.streak ?? 0}-day streak
            </h1>
            <p className="mt-3 max-w-xl">
              You've studied {minutes} minutes this week. Your AI Teacher has a practical class ready
              that focuses on your weakest topic.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Link to="/teacher"><Button variant="sun">Start AI Teacher class</Button></Link>
              <Link to="/courses"><Button variant="ghost">Browse courses</Button></Link>
            </div>
          </div>
          <div className="justify-self-center rounded-full bg-white/15 p-3">
            <ProgressRing value={avg} color="#FFC93C" size={120} label="Average course progress" />
          </div>
        </div>
      </header>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <p className="text-sm font-bold text-ink/75">Learning streak</p>
          <p className="mt-2 font-display text-4xl font-extrabold">{twin?.streak ?? 0} days 🔥</p>
        </Card>
        <Card>
          <p className="text-sm font-bold text-ink/75">Minutes this week</p>
          <p className="mt-2 font-display text-4xl font-extrabold">{minutes}</p>
        </Card>
        <Card>
          <p className="text-sm font-bold text-ink/75">Focus score</p>
          <p className="mt-2 font-display text-4xl font-extrabold">{twin?.focus ?? "–"}<span className="text-lg">/100</span></p>
        </Card>
      </div>

      {twin && (
        <Card>
          <SectionTitle>Study time, last 7 days</SectionTitle>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={twin.weeklyMinutes}>
                <defs>
                  <linearGradient id="mins" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6D4AFF" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#6D4AFF" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#EFE7FF" vertical={false} />
                <XAxis dataKey="day" stroke="#2B1F4A" tickLine={false} />
                <YAxis stroke="#2B1F4A" tickLine={false} axisLine={false} />
                <Tooltip />
                <Area type="monotone" dataKey="minutes" stroke="#6D4AFF" strokeWidth={3} fill="url(#mins)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
      )}

      <section aria-labelledby="continue">
        <SectionTitle>
          <span id="continue">Continue learning</span>
        </SectionTitle>
        {enrolled.length ? (
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {enrolled.map((c) => <CourseCard key={c.id} course={c} />)}
          </div>
        ) : (
          <p className="font-semibold">You're not enrolled in any courses yet. Visit <Link className="text-violet underline" to="/courses">Courses</Link> to start.</p>
        )}
      </section>
    </div>
  );
}
