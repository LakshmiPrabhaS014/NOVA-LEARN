import { useEffect, useState } from "react";
import { Bar as ChartBar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api, type Twin } from "../lib/api";
import { useSession } from "../App";
import { Card, ProgressRing, SectionTitle, TwinOrb } from "../components/ui";

export default function TwinPage() {
  const { user } = useSession();
  const [twin, setTwin] = useState<Twin | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    api<Twin>(`/twin/${user.id}`).then(setTwin).catch((e: Error) => setError(e.message));
  }, [user?.id]);

  if (error) return <Card><p role="alert" className="font-semibold">{error}</p></Card>;
  if (!twin) return <p className="font-semibold">Loading your Learning Twin…</p>;

  const masteryData = Object.entries(twin.mastery).map(([topic, score]) => ({ topic, score }));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-4xl font-extrabold">Your AI Learning Twin</h1>
        <p className="mt-2 max-w-2xl font-semibold">A living model of how you learn. It updates after every lesson, checkpoint, and quiz.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
        <Card className="flex flex-col items-center">
          <TwinOrb mastery={twin.mastery} />
          <p className="mt-2 text-center text-sm font-semibold">Each orbiting dot is a topic. Its size shows your mastery.</p>
        </Card>

        <div className="space-y-6">
          <Card>
            <SectionTitle>Learning profile</SectionTitle>
            <div className="grid grid-cols-3 justify-items-center gap-2">
              <div className="text-center"><ProgressRing value={twin.retention} color="#14B8A6" size={92} label="Retention" /><p className="font-bold">Retention</p></div>
              <div className="text-center"><ProgressRing value={twin.focus} color="#FF5FA2" size={92} label="Focus" /><p className="font-bold">Focus</p></div>
              <div className="text-center"><ProgressRing value={Math.min(100, Math.round(twin.pace * 50))} color="#FFC93C" size={92} label="Pace" /><p className="font-bold">Pace {twin.pace}×</p></div>
            </div>
          </Card>

          <Card>
            <SectionTitle>Next best steps</SectionTitle>
            <ul className="space-y-3">
              {twin.recommendations.map((r) => (
                <li key={r.topic} className="rounded-2xl bg-[#faf7ff] p-4">
                  <p className="font-bold">{r.topic} · {r.score}%</p>
                  <p className="text-sm">{r.action}</p>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>

      <Card>
        <SectionTitle>Mastery by topic</SectionTitle>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={masteryData}>
              <CartesianGrid stroke="#EFE7FF" vertical={false} />
              <XAxis dataKey="topic" stroke="#2B1F4A" tickLine={false} />
              <YAxis domain={[0, 100]} stroke="#2B1F4A" tickLine={false} axisLine={false} />
              <Tooltip />
              <ChartBar dataKey="score" fill="#6D4AFF" radius={[12, 12, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}
