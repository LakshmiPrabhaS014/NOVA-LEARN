/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#2B1F4A",     // primary text, 13:1 on white
        coral: "#FF6B5A",   // decorative and large shapes
        sun: "#FFC93C",
        teal: "#14B8A6",
        violet: "#6D4AFF",  // primary buttons (white text, 5.4:1)
        pink: "#FF5FA2",
        lime: "#A3E635",
        cream: "#FFF9F5",
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', "system-ui", "sans-serif"],
        body: ["Figtree", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 12px 32px -14px rgba(74, 40, 120, 0.28), 0 2px 6px -2px rgba(74, 40, 120, 0.12)",
        pop: "0 18px 40px -16px rgba(201, 58, 42, 0.45)",
      },
    },
  },
  plugins: [],
};
