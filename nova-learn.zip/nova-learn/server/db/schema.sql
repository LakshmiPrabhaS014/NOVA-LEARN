-- NOVA Learn schema (PostgreSQL 14+)
create table if not exists users (
  id            serial primary key,
  name          text not null,
  email         text unique not null,
  role          text not null check (role in ('student', 'instructor', 'admin')),
  avatar_color  text not null default '#B9A7FF'
);

create table if not exists courses (
  id             serial primary key,
  title          text not null,
  description    text not null default '',
  category       text not null default 'General',
  level          text not null default 'Beginner',
  color          text not null default '#FF5FA2',
  emoji          text not null default '📘',
  status         text not null default 'draft' check (status in ('draft', 'published', 'archived')),
  instructor_id  int not null references users(id),
  created_at     timestamptz not null default now()
);

create table if not exists lessons (
  id            serial primary key,
  course_id     int not null references courses(id) on delete cascade,
  title         text not null,
  duration_min  int not null default 10,
  position      int not null
);

create table if not exists enrollments (
  user_id      int references users(id) on delete cascade,
  course_id    int references courses(id) on delete cascade,
  progress     int not null default 0 check (progress between 0 and 100),
  enrolled_at  timestamptz not null default now(),
  last_active  timestamptz not null default now(),
  primary key (user_id, course_id)
);

create table if not exists lesson_completions (
  user_id       int references users(id) on delete cascade,
  lesson_id     int references lessons(id) on delete cascade,
  completed_at  timestamptz not null default now(),
  primary key (user_id, lesson_id)
);

create table if not exists quizzes (
  id         serial primary key,
  course_id  int not null references courses(id) on delete cascade,
  title      text not null
);

create table if not exists questions (
  id            serial primary key,
  quiz_id       int not null references quizzes(id) on delete cascade,
  prompt        text not null,
  options       jsonb not null,
  answer_index  int not null,
  topic         text not null
);

create table if not exists quiz_attempts (
  id               serial primary key,
  user_id          int references users(id) on delete cascade,
  quiz_id          int references quizzes(id) on delete cascade,
  score            int not null,
  total            int not null,
  topic_breakdown  jsonb not null,
  created_at       timestamptz not null default now()
);

create table if not exists twin_profiles (
  user_id     int primary key references users(id) on delete cascade,
  pace        numeric(3, 2) not null default 1.00,
  retention   int not null default 70,
  focus       int not null default 70,
  mastery     jsonb not null default '{}'::jsonb,
  streak      int not null default 0,
  updated_at  timestamptz not null default now()
);

create table if not exists study_sessions (
  id           serial primary key,
  user_id      int references users(id) on delete cascade,
  session_date date not null default current_date,
  minutes      int not null
);
