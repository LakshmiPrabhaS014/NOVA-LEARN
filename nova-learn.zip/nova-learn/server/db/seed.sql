-- Sample data for NOVA Learn. Safe to re-run: it clears existing rows first.
truncate users, courses, lessons, quizzes, questions, enrollments,
         lesson_completions, quiz_attempts, twin_profiles, study_sessions
restart identity cascade;

insert into users (id, name, email, role, avatar_color) values
  (1, 'Aanya Sharma', 'aanya@nova.test', 'student',    '#FF9C8F'),
  (2, 'Rohan Mehta',  'rohan@nova.test', 'instructor', '#B9A7FF'),
  (3, 'Priya Nair',   'priya@nova.test', 'admin',      '#7EE0D4'),
  (4, 'Kabir Singh',  'kabir@nova.test', 'student',    '#FFE07A'),
  (5, 'Meera Iyer',   'meera@nova.test', 'student',    '#FFB3D6'),
  (6, 'Dev Patel',    'dev@nova.test',   'student',    '#D6F77A'),
  (7, 'Lena Fischer', 'lena@nova.test',  'instructor', '#FFC08A');

insert into courses (id, title, description, category, level, color, emoji, status, instructor_id) values
  (1, 'Data Storytelling with Charts', 'Turn messy numbers into charts that persuade a room.', 'Analytics', 'Beginner', '#6D4AFF', '📊', 'published', 2),
  (2, 'UX Foundations for Product Teams', 'Map user journeys, sketch flows and run quick usability tests.', 'Design', 'Beginner', '#FF5FA2', '🎨', 'published', 2),
  (3, 'Python for Curious Minds', 'Variables, loops and small projects that do something useful.', 'Programming', 'Intermediate', '#14B8A6', '🐍', 'published', 2),
  (4, 'Money Basics: Budgets and Savings', 'Build a monthly budget and a savings plan you will actually keep.', 'Finance', 'Beginner', '#C98A00', '💰', 'draft', 7);

insert into lessons (id, course_id, title, duration_min, position) values
  (1, 1, 'Why charts persuade', 10, 1),
  (2, 1, 'Choosing the right chart', 12, 2),
  (3, 1, 'Cleaning data before plotting', 15, 3),
  (4, 1, 'Telling a story with one slide', 14, 4),
  (5, 2, 'What UX research really is', 9, 1),
  (6, 2, 'Journey maps in 30 minutes', 13, 2),
  (7, 2, 'Running a five-user test', 16, 3),
  (8, 3, 'Variables and types', 11, 1),
  (9, 3, 'Loops without the fear', 14, 2),
  (10, 3, 'Functions that earn their keep', 15, 3),
  (11, 3, 'Mini project: a habit tracker', 25, 4),
  (12, 4, 'Know where your money goes', 10, 1),
  (13, 4, 'Building a realistic budget', 12, 2),
  (14, 4, 'Savings that survive a bad month', 11, 3);

insert into quizzes (id, course_id, title) values
  (1, 1, 'Charts check-in'),
  (2, 3, 'Python basics check-in');

insert into questions (id, quiz_id, prompt, options, answer_index, topic) values
  (1, 1, 'Which chart best shows change over time?', '["Pie chart","Line chart","Scatter plot","Donut chart"]', 1, 'Charts'),
  (2, 1, 'What should you do first with messy data?', '["Pick a colour palette","Clean and validate it","Add animations","Export to PDF"]', 1, 'Storytelling'),
  (3, 1, 'A slide should usually make one point.', '["True","False"]', 0, 'Storytelling'),
  (4, 1, 'Which chart compares categories side by side?', '["Bar chart","Area chart","Heatmap","Histogram"]', 0, 'Charts'),
  (5, 2, 'Which line creates a variable holding the number 5?', '["int x = 5","x = 5","let x = 5","var x = 5"]', 1, 'Variables'),
  (6, 2, 'What does range(3) produce?', '["0, 1, 2","1, 2, 3","0, 1, 2, 3","3"]', 0, 'Loops'),
  (7, 2, 'Which keyword exits a loop early?', '["stop","exit","break","end"]', 2, 'Loops'),
  (8, 2, 'Which keyword sends a value back from a function?', '["print","return","yield_all","output"]', 1, 'Functions');

insert into enrollments (user_id, course_id, progress, enrolled_at, last_active) values
  (1, 1, 50, now() - interval '5 months', now() - interval '1 day'),
  (1, 3, 25, now() - interval '2 months', now() - interval '2 hours'),
  (1, 2,  0, now() - interval '3 weeks', now() - interval '3 weeks'),
  (4, 1, 75, now() - interval '4 months', now() - interval '3 days'),
  (4, 2, 33, now() - interval '1 month', now() - interval '1 day'),
  (5, 3, 50, now() - interval '6 months', now() - interval '5 days'),
  (6, 1, 25, now() - interval '2 months', now() - interval '6 days'),
  (6, 2, 67, now() - interval '1 month', now() - interval '2 days');

insert into lesson_completions (user_id, lesson_id) values
  (1, 1), (1, 2), (1, 8),
  (4, 1), (4, 2), (4, 3), (4, 5),
  (5, 8), (5, 9),
  (6, 1), (6, 5), (6, 6);

insert into quiz_attempts (user_id, quiz_id, score, total, topic_breakdown) values
  (1, 1, 3, 4, '{"Charts":{"correct":2,"total":2},"Storytelling":{"correct":1,"total":2}}'),
  (4, 1, 4, 4, '{"Charts":{"correct":2,"total":2},"Storytelling":{"correct":2,"total":2}}'),
  (5, 2, 2, 4, '{"Variables":{"correct":1,"total":1},"Loops":{"correct":1,"total":2},"Functions":{"correct":0,"total":1}}');

insert into twin_profiles (user_id, pace, retention, focus, mastery, streak) values
  (1, 1.20, 74, 81, '{"Charts":78,"Storytelling":55,"Variables":64,"Loops":40,"Functions":52}', 6),
  (4, 1.00, 80, 76, '{"Charts":88,"Storytelling":82,"Research":60}', 9),
  (5, 0.85, 68, 90, '{"Variables":84,"Loops":71,"Functions":58}', 3),
  (6, 1.35, 62, 58, '{"Charts":45,"Storytelling":50,"Research":72}', 2);

-- Seven days of study time per learner, with varied minutes.
insert into study_sessions (user_id, session_date, minutes)
select u, current_date - d, 25 + ((u * 7 + d * 13) % 45)
from (values (1), (4), (5), (6)) as learners(u), generate_series(0, 6) as days(d);

select setval(pg_get_serial_sequence('users', 'id'), (select max(id) from users));
select setval(pg_get_serial_sequence('courses', 'id'), (select max(id) from courses));
select setval(pg_get_serial_sequence('lessons', 'id'), (select max(id) from lessons));
select setval(pg_get_serial_sequence('quizzes', 'id'), (select max(id) from quizzes));
select setval(pg_get_serial_sequence('questions', 'id'), (select max(id) from questions));
