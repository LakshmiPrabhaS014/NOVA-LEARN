import pg from "pg";

export const pool = new pg.Pool({
  connectionString:
    process.env.DATABASE_URL ?? "postgres://postgres:postgres@localhost:5432/nova_learn",
});

export const query = async <T = any>(text: string, params: unknown[] = []) =>
  (await pool.query<T>(text, params)).rows;
