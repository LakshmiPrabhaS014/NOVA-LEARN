import express, { type Request, type Response } from "express";
import cors from "cors";
import { query } from "./db.js";
import { updateTwinMastery, buildRecommendations, type TopicResult } from "./twin.js";

const app = express();
app.use(cors());
app.use(express.json());

type Handler = (req: Request, res: Response) => Promise<unknown>;
const wrap =
  (fn: Handler) =>
  (req: Request, res: Response) =>
    fn(req, res).catch((err) => {
      console.error(err);
      res.status(500).json({ error: "The server could not finish this request. Check the server logs." });
    });

const COURSE_STATUSES = ["draft", "published", "archived"];

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

// ---------- Users ----------
app.get("/api/users", wrap(async (_req, res) => {
  res.json(await query(`select id, name, email, role, avatar_color from users order by id`));
}));

app.patch("/api/users/:id", wrap(async (req, res) => {
  const { role } = req.body ?? {};
  if (!["student", "instructor", "admin"].includes(role)) {
    return void res.status(400).json({ error: "Role must be student, instructor, or admin." });
  }
  const [row] = await query(
    `update users set role = $2 where id = $1 returning id, name, email, role, avatar_color`,
    [req.params.id, role],
  );
  if (!row) return void res.status(404).json({ error: "User not found." });
  res.json(row);
}));

// ---------- Courses ----------
app.get("/api/courses", wrap(async (req, res) => {
  const userId = Number(req.query.userId ?? 0);
  res.json(
    await query(
      `select c.id, c.title, c.description, c.category, c.level, c.color, c.emoji, c.status,
              u.name as instructor,
              coalesce(e.progress, 0) as progress,
              (e.user_id is not null) as enrolled,
              (select count(*) from enrollments x where x.course_id = c.id)::int as learners
       from courses c
       join users u on u.id = c.instructor_id
       left join enrollments e on e.course_id = c.id and e.user_id = $1
       order by c.id`,
      [userId],
    ),
  );
}));

app.get("/api/courses/:id", wrap(async (req, res) => {
  const id = Number(req.params.id);
  const userId = Number(req.query.userId ?? 0);
  const [course] = await query(
    `select c.*, u.name as instructor from courses c join users u on u.id = c.instructor_id where c.id = $1`,
    [id],
  );
  if (!course) return void res.status(404).json({ error: "This course does not exist." });

  const lessons = await query(
    `select l.id, l.title, l.duration_min, l.position, (lc.user_id is not null) as completed
     from lessons l
     left join lesson_completions lc on lc.lesson_id = l.id and lc.user_id = $2
     where l.course_id = $1 order by l.position`,
    [id, userId],
  );
  const quizzes = await query(`select id, title from quizzes where course_id = $1`, [id]);
  res.json({ ...course, lessons, quizzes });
}));

app.post("/api/courses", wrap(async (req, res) => {
  const { title, description, category, level, instructorId, color, emoji } = req.body ?? {};
  if (!title?.trim() || !instructorId) {
    return void res.status(400).json({ error: "Give the course a title. Instructor is required." });
  }
  const [row] = await query(
    `insert into courses (title, description, category, level, instructor_id, color, emoji, status)
     values ($1, $2, $3, $4, $5, $6, $7, 'draft') returning *`,
    [title.trim(), description ?? "", category ?? "General", level ?? "Beginner", instructorId,
     color ?? "#FF5FA2", emoji ?? "✨"],
  );
  res.status(201).json(row);
}));

app.patch("/api/courses/:id", wrap(async (req, res) => {
  const { status } = req.body ?? {};
  if (!COURSE_STATUSES.includes(status)) {
    return void res.status(400).json({ error: "Status must be draft, published, or archived." });
  }
  const [row] = await query(`update courses set status = $2 where id = $1 returning *`, [req.params.id, status]);
  if (!row) return void res.status(404).json({ error: "This course does not exist." });
  res.json(row);
}));

app.post("/api/courses/:id/enroll", wrap(async (req, res) => {
  await query(
    `insert into enrollments (user_id, course_id) values ($1, $2) on conflict do nothing`,
    [req.body?.userId, req.params.id],
  );
  res.status(201).json({ ok: true });
}));

// ---------- Lessons & progress ----------
app.post("/api/lessons/:id/complete", wrap(async (req, res) => {
  const lessonId = Number(req.params.id);
  const userId = Number(req.body?.userId);
  const [lesson] = await query(`select course_id from lessons where id = $1`, [lessonId]);
  if (!lesson) return void res.status(404).json({ error: "This lesson does not exist." });

  await query(
    `insert into lesson_completions (user_id, lesson_id) values ($1, $2) on conflict do nothing`,
    [userId, lessonId],
  );
  const [{ ratio }] = await query(
    `select (select count(*) from lesson_completions lc join lessons l on l.id = lc.lesson_id
             where lc.user_id = $1 and l.course_id = $2)::float
            / nullif((select count(*) from lessons where course_id = $2), 0) as ratio`,
    [userId, lesson.course_id],
  );
  const progress = Math.round((ratio ?? 0) * 100);
  await query(
    `insert into enrollments (user_id, course_id, progress) values ($1, $2, $3)
     on conflict (user_id, course_id) do update set progress = excluded.progress, last_active = now()`,
    [userId, lesson.course_id, progress],
  );
  await query(
    `insert into study_sessions (user_id, minutes) values ($1, 15)`,
    [userId],
  );
  res.json({ progress });
}));

// ---------- Quizzes ----------
app.get("/api/quizzes/:id", wrap(async (req, res) => {
  const [quiz] = await query(`select id, title, course_id from quizzes where id = $1`, [req.params.id]);
  if (!quiz) return void res.status(404).json({ error: "This quiz does not exist." });
  // Answers are never sent to the client.
  const questions = await query(
    `select id, prompt, options, topic from questions where quiz_id = $1 order by id`,
    [quiz.id],
  );
  res.json({ ...quiz, questions });
}));

app.post("/api/quizzes/:id/attempt", wrap(async (req, res) => {
  const quizId = Number(req.params.id);
  const userId = Number(req.body?.userId);
  const answers: Record<string, number> = req.body?.answers ?? {};
  const questions = await query(
    `select id, answer_index, topic from questions where quiz_id = $1`,
    [quizId],
  );
  if (!questions.length) return void res.status(404).json({ error: "This quiz does not exist." });

  const topics: Record<string, TopicResult> = {};
  let score = 0;
  for (const q of questions) {
    const t = (topics[q.topic] ??= { correct: 0, total: 0 });
    t.total++;
    if (answers[String(q.id)] === q.answer_index) {
      score++;
      t.correct++;
    }
  }

  const [attempt] = await query(
    `insert into quiz_attempts (user_id, quiz_id, score, total, topic_breakdown)
     values ($1, $2, $3, $4, $5) returning id`,
    [userId, quizId, score, questions.length, JSON.stringify(topics)],
  );
  await updateTwinMastery(userId, topics);
  res.status(201).json({ attemptId: attempt.id, score, total: questions.length, topics });
}));

// ---------- AI Learning Twin ----------
app.get("/api/twin/:userId", wrap(async (req, res) => {
  const uid = Number(req.params.userId);
  const [twin] = await query(`select * from twin_profiles where user_id = $1`, [uid]);
  if (!twin) {
    return void res.status(404).json({ error: "No Learning Twin yet. Complete a lesson to start one." });
  }
  const weeklyMinutes = await query(
    `select to_char(d::date, 'Dy') as day, coalesce(sum(s.minutes), 0)::int as minutes
     from generate_series(current_date - 6, current_date, interval '1 day') d
     left join study_sessions s on s.session_date = d::date and s.user_id = $1
     group by d order by d`,
    [uid],
  );
  res.json({
    ...twin,
    weeklyMinutes,
    recommendations: buildRecommendations(twin.mastery),
  });
}));

// ---------- Instructor analytics ----------
app.get("/api/instructor/:id/analytics", wrap(async (req, res) => {
  res.json(
    await query(
      `select c.id, c.title, c.status, c.color, c.emoji,
              count(e.user_id)::int as learners,
              coalesce(round(avg(e.progress)), 0)::int as avg_progress,
              (select round(avg(qa.score::float / qa.total) * 100)
                 from quiz_attempts qa join quizzes qz on qz.id = qa.quiz_id
                 where qz.course_id = c.id)::int as avg_quiz
       from courses c
       left join enrollments e on e.course_id = c.id
       where c.instructor_id = $1
       group by c.id order by c.id`,
      [req.params.id],
    ),
  );
}));

// ---------- Admin overview ----------
app.get("/api/admin/overview", wrap(async (_req, res) => {
  const [totals] = await query(
    `select (select count(*) from users where role = 'student')::int as students,
            (select count(*) from users where role = 'instructor')::int as instructors,
            (select count(*) from courses)::int as courses,
            (select count(*) from enrollments)::int as enrollments,
            coalesce((select round(avg(progress)) from enrollments), 0)::int as avg_progress`,
  );
  const monthly = await query(
    `select to_char(date_trunc('month', enrolled_at), 'Mon') as month, count(*)::int as enrollments
     from enrollments group by date_trunc('month', enrolled_at)
     order by date_trunc('month', enrolled_at)`,
  );
  const users = await query(
    `select u.id, u.name, u.email, u.role, u.avatar_color,
            (select count(*) from enrollments e where e.user_id = u.id)::int as enrollments
     from users u order by u.id`,
  );
  res.json({ totals, monthly, users });
}));

// ---------- AI Teacher: practical class builder ----------
app.get("/api/teacher/class/:courseId", wrap(async (req, res) => {
  const courseId = Number(req.params.courseId);
  const userId = Number(req.query.userId ?? 0);
  const [course] = await query(`select id, title from courses where id = $1`, [courseId]);
  if (!course) return void res.status(404).json({ error: "This course does not exist." });

  const [twin] = await query(`select mastery from twin_profiles where user_id = $1`, [userId]);
  const mastery: Record<string, number> = twin?.mastery ?? {};
  const weakest = Object.entries(mastery).sort((a, b) => a[1] - b[1])[0];
  const lessons = await query(
    `select id, title, duration_min from lessons where course_id = $1 order by position`,
    [courseId],
  );
  const [checkpoint] = weakest
    ? await query(
        `select q.id, q.prompt, q.options, q.topic
         from questions q join quizzes z on z.id = q.quiz_id
         where z.course_id = $1 and q.topic = $2 order by q.id limit 1`,
        [courseId, weakest[0]],
      )
    : [];

  const steps = [
    {
      type: "warm-up",
      title: "Warm-up: recall",
      minutes: 5,
      text: `Before we start ${course.title}, tell the teacher in one sentence what you remember from last time.`,
    },
    ...lessons.map((l: { id: number; title: string; duration_min: number }) => ({
      type: "lesson",
      lessonId: l.id,
      title: l.title,
      minutes: l.duration_min,
      text: `Watch the short demo, then try the hands-on step for "${l.title}".`,
    })),
    ...(checkpoint
      ? [{
          type: "checkpoint",
          title: `Checkpoint: ${checkpoint.topic}`,
          minutes: 3,
          questionId: checkpoint.id,
          prompt: checkpoint.prompt,
          options: checkpoint.options,
          text: "Your Learning Twin flagged this topic as the weakest, so the teacher spends extra time here.",
        }]
      : []),
  ];

  res.json({
    courseTitle: course.title,
    teacherNote: weakest
      ? `Today's focus is ${weakest[0]}, your lowest mastery at ${weakest[1]}%. The lessons stay in order, but this checkpoint gets extra time.`
      : "No Learning Twin data yet, so the class follows the standard lesson order.",
    steps,
  });
}));

app.post("/api/teacher/checkpoint", wrap(async (req, res) => {
  const { questionId, answerIndex, userId } = req.body ?? {};
  const [q] = await query(`select answer_index, topic from questions where id = $1`, [questionId]);
  if (!q) return void res.status(404).json({ error: "Checkpoint question not found." });
  const correct = Number(answerIndex) === q.answer_index;
  await updateTwinMastery(Number(userId), { [q.topic]: { correct: correct ? 1 : 0, total: 1 } });
  res.json({ correct, correctIndex: q.answer_index });
}));

const port = Number(process.env.PORT ?? 4000);
app.listen(port, () => console.log(`NOVA Learn API running on http://localhost:${port}`));
