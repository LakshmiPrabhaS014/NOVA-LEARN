import { query } from "./db.js";

export type TopicResult = { correct: number; total: number };

/**
 * Blends the new quiz result into the learner's Learning Twin mastery map.
 * Existing topics move 40% toward the latest result, so one bad quiz does not erase progress.
 */
export async function updateTwinMastery(userId: number, topics: Record<string, TopicResult>) {
  const [twin] = await query<{ mastery: Record<string, number> }>(
    `select mastery from twin_profiles where user_id = $1`,
    [userId],
  );
  const mastery: Record<string, number> = { ...(twin?.mastery ?? {}) };

  for (const [topic, r] of Object.entries(topics)) {
    const observed = Math.round((r.correct / r.total) * 100);
    mastery[topic] =
      mastery[topic] === undefined ? observed : Math.round(mastery[topic] * 0.6 + observed * 0.4);
  }

  await query(
    `insert into twin_profiles (user_id, mastery) values ($1, $2)
     on conflict (user_id) do update set mastery = excluded.mastery, updated_at = now()`,
    [userId, JSON.stringify(mastery)],
  );
}

/** Turns the weakest topics into concrete next steps the student can act on. */
export function buildRecommendations(mastery: Record<string, number>) {
  return Object.entries(mastery)
    .sort((a, b) => a[1] - b[1])
    .slice(0, 3)
    .map(([topic, score]) => ({
      topic,
      score,
      action:
        score < 60
          ? `Review ${topic} with a 10-minute drill`
          : `Push ${topic} to mastery with a stretch quiz`,
    }));
}
